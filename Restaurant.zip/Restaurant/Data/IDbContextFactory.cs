using System.Data.Entity;

namespace Omu.Restaurants.Data
{
    public interface IDbContextFactory
    {
        DbContext GetContext();
    }
}