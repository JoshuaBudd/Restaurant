using System;

namespace Omu.Restaurant.Core
{
    [Serializable]
    public class RestaurantException : Exception
    {
        public RestaurantException(string message)
            : base(message)
        {
        }
    }
}