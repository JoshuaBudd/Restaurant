namespace Omu.Restaurants.Core.Model
{
    public class Feedback : Entity
    {
        public string Comments { get; set; }
    }
}