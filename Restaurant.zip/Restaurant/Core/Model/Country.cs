namespace Omu.Restaurants.Core.Model
{
    public class Country : DelEntity
    {
        public string Name { get; set; }
    }
}