namespace Omu.Restaurants.Core.Model
{
    public class Entity
    {
        public int Id { get; set; }
    }
}