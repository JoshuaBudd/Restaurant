namespace Omu.Restaurants.Core.Model
{
    public interface IDel
    {
        bool IsDeleted { get; set; }
    }
}