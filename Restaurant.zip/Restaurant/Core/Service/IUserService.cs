using Omu.Restaurants.Core.Model;

namespace Omu.Restaurants.Core.Service
{
    public interface IUserService : ICrudService<User>
    {
        bool IsUnique(string login);
        
        void ChangePassword(int id, string password);
        
        User Get(string login, string password);
    }
}