using System;

namespace Omu.Restaurant.Core
{
    public class ProArgumentNullException : ArgumentNullException
    {
        public ProArgumentNullException(string paramName) : base(paramName)
        {
        }
    }
}