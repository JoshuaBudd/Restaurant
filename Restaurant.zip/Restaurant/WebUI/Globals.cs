namespace Omu.Restaurants.WebUI
{
    public static class Globals
    {
        public static string PicturesPath { get; set; }
    }
}