using Omu.Encrypto;
using Omu.Restaurants.Core.Service;
using Omu.Restaurants.Infra;
using Omu.Restaurants.Service;

namespace Omu.Restaurants.WebUI.App_Start
{
    public class WindsorConfig
    {
        public static void Configure()
        {
            WindsorRegistrar.Register(typeof(IHasher), typeof(Hasher));
            WindsorRegistrar.Register(typeof(IUserService), typeof(UserService));
            WindsorRegistrar.Register(typeof(IMealService), typeof(MealService));

            WindsorRegistrar.RegisterAllFromAssemblies("Omu.Restaurants.Data");
            WindsorRegistrar.RegisterAllFromAssemblies("Omu.Restaurants.Service");
            WindsorRegistrar.RegisterAllFromAssemblies("Omu.Restaurants.Infra");
            WindsorRegistrar.RegisterAllFromAssemblies("Omu.Restaurants.WebUI");
        }
    }
}