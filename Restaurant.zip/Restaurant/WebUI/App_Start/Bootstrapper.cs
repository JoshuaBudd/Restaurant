using System.Security.Claims;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

using Omu.Restaurants.Infra;
using Omu.Restaurants.WebUI.Mappers;
using Omu.Restaurants.WebUI.Utils;

namespace Omu.Restaurants.WebUI.App_Start
{
    public class Bootstrapper
    {
        public static void Bootstrap()
        {
            RouteConfigurator.RegisterRoutes(RouteTable.Routes);
            ControllerBuilder.Current.SetControllerFactory(new WindsorControllerFactory(IoC.Container));
            WindsorConfig.Configure();
            AwesomeConfig.Configure();
            MapperConfig.Configure();
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            
            FilterProviders.Providers.Add(new AntiForgeryTokenFilter());
            AntiForgeryConfig.UniqueClaimTypeIdentifier = ClaimTypes.Name;

            Globals.PicturesPath = HttpContext.Current.Server.MapPath("~/pictures");
            new Worker().Start();
        }
    }
}