namespace Omu.ProDinner.WebUI.ViewModels.Display
{
    public class DelBtn
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsDeleted { get; set; }
    }
}