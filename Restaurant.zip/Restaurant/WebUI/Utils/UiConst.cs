namespace Omu.ProDinner.WebUI.Utils
{
    public class UiConst
    {
        public const string IcoEdit = "<span class=\"ico-crud ico-edit\"></span>";
    }
}