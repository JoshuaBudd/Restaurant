using System.Web.Mvc;

namespace Omu.ProDinner.WebUI.Utils
{
    public class IgnoreAntiforgeryTokenAttribute : FilterAttribute
    {
    }
}