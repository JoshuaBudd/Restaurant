using Microsoft.Owin;

using Omu.Restaurants.WebUI;
using Omu.Restaurants.WebUI.App_Start;

using Owin;

[assembly: OwinStartup(typeof(Startup))]

namespace Omu.Restaurants.WebUI
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            OwinConfig.ConfigureAuth(app);
        }
    }
}