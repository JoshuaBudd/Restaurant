using FakeItEasy;
using NUnit.Framework;
using Omu.Restaurants.Core;
using Omu.Restaurants.Core.Model;
using Omu.Restaurants.Core.Service;
using Omu.Restaurants.Infra;
using Omu.Restaurants.WebUI.Mappers;
using Omu.Restaurants.WebUI.Controllers;
using Omu.Restaurants.WebUI.ViewModels.Input;

namespace Omu.Restaurants.Tests
{
    public class CruderControllerTests
    {
        CountryController countryController;

        IProMapper mapper;

        ICrudService<Country> countryCrudSrv;

        [SetUp]
        public void SetUp()
        {
            mapper = A.Fake<IProMapper>();
            countryCrudSrv = A.Fake<ICrudService<Country>>();
            countryController = new CountryController(countryCrudSrv, mapper, A.Fake<ICacheManager>());
        }

        [Test]
        public void CreateShouldBuildNewInput()
        {
            countryController.Create();
            A.CallTo(() => mapper.Map<Country, CountryInput>(A<Country>.Ignored, null)).MustHaveHappened();
        }

        [Test]
        public void CreateShouldReturnViewForInvalidModelstate()
        {
            countryController.ModelState.AddModelError("", "");
            countryController.Create(A.Fake<CountryInput>(), null).ShouldBePartialViewResult();
        }

        [Test]
        public void EditShouldReturnCreateView()
        {
            A.CallTo(() => countryCrudSrv.Get(1)).Returns(A.Fake<Country>());

            countryController.Edit(1).ShouldBePartialViewResult().ShouldBeCreate();

            A.CallTo(() => countryCrudSrv.Get(1)).MustHaveHappened();
        }

        [Test]
        public void EditShouldReturnViewForInvalidModelstate()
        {
            countryController.ModelState.AddModelError("", "");
            countryController.Edit(A.Fake<CountryInput>(), null).ShouldBePartialViewResult().ShouldBeCreate();
        }

        [Test]
        public void EditShouldReturnContentOnError()
        {
            A.CallTo(() => mapper.Map<CountryInput, Country>(A<CountryInput>.Ignored, A<Country>.Ignored)).Throws(new RestaurantsException("aa"));
            countryController.Edit(new CountryInput { Id = 1 }, null).ShouldBeContent().Content.ShouldEqual("aa");
        }

        [Test]
        public void DeleteShouldReturnView()
        {
            countryController.Delete(1, "").ShouldBePartialViewResult();
        }

        [Test]
        public void DeleteShouldDeleteEntity()
        {
            var input = new DeleteConfirmInput { Id = 123 };

            countryController.Delete(input).ShouldBeJson();
            A.CallTo(() => countryCrudSrv.Delete(input.Id)).MustHaveHappened();
        }
    }
}