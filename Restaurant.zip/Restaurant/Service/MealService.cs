using Omu.Restaurant.Core.Model;
using Omu.Restaurant.Core.Repository;
using Omu.Restaurant.Core.Service;

namespace Omu.Restaurant.Service
{
    public class MealService : CrudService<Meal>, IMealService
    {
        private readonly IFileManagerService fileManagerService;

        public MealService(IRepo<Meal> repo, IFileManagerService fileManagerService) : base(repo)
        {
            this.fileManagerService = fileManagerService;
        }

        public void SetPicture(int id, string root, string filename, int x, int y, int w, int h)
        {
            fileManagerService.MakeImages(root, filename, x, y, w, h);

            var meal = repo.Get(id);

            if (meal.Picture == filename)
            {
                return;
            }

            var oldPictureFileName = meal.Picture;
            meal.Picture = filename;
            repo.Save();

            if (!string.IsNullOrWhiteSpace(oldPictureFileName))
            {
                fileManagerService.DeleteImages(root, oldPictureFileName);
            }
        }
    }
}